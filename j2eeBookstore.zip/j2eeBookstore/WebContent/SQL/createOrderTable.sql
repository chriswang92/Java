use example;  
create table orderTable(  
orderid int primary key auto_increment,  
username varchar(30) NOT NULL,  
bookname varchar(30) NOT NULL,  
author varchar(30) NOT NULL,
price double NOT NULL,
display int NOT NULL DEFAULT 1
);  
insert into orderTable(orderid,username,bookname,author,price,display) values (null,'chris','sanguoyanyi','luoguanzhong',32.99,1);