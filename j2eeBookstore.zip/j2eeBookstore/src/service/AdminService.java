package service;

import java.util.List;

import bean.User;

public interface AdminService {
	public List<User> getAllUser();
	
}
